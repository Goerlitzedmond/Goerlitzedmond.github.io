import numpy as np


class GameExperience(object):
    """
    Reconstruction of the instructor-provided GameExperience class, built to
    match the constructor signature and method calls used in the original
    notebook: GameExperience(model, target_model, max_memory=...),
    experience.remember(episode), experience.predict(envstate), and
    experience.get_data(batch_size=...). This is a local stand-in for testing
    only, since the real file is no longer accessible (Codio access lost).
    """

    def __init__(self, model, target_model=None, max_memory=100, discount=0.95):
        self.model = model
        self.target_model = target_model if target_model is not None else model
        self.max_memory = max_memory
        self.discount = discount
        self.memory = list()
        self.num_actions = model.output_shape[-1]

    def remember(self, episode):
        self.memory.append(episode)
        if len(self.memory) > self.max_memory:
            del self.memory[0]

    def predict(self, envstate):
        state = np.asarray(envstate, dtype=np.float32)
        return self.model(state, training=False).numpy()[0]

    def get_data(self, batch_size=10):
        env_size = self.memory[0][0].shape[1]
        mem_size = len(self.memory)
        data_size = min(mem_size, batch_size)
        inputs = np.zeros((data_size, env_size), dtype=np.float32)
        targets = np.zeros((data_size, self.num_actions), dtype=np.float32)

        for i, j in enumerate(np.random.choice(range(mem_size), data_size, replace=False)):
            envstate, action, reward, next_envstate, game_status = self.memory[j]
            inputs[i] = envstate
            targets[i] = self.predict(envstate)

            next_state = np.asarray(next_envstate, dtype=np.float32)
            next_q = self.target_model(next_state, training=False).numpy()[0]
            Q_sa = np.max(next_q)

            if game_status == 'win' or game_status == 'lose':
                targets[i, action] = reward
            else:
                targets[i, action] = reward + self.discount * Q_sa

        return inputs, targets
