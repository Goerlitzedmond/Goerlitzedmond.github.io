# Original, unmodified code from my graded CS 370 submission
# (extracted from Edmond_Goerlitz_ProjectTwoMilestone.html)

def build_model(maze):
    model = Sequential()
    model.add(Dense(maze.size, input_shape=(maze.size,)))
    model.add(PReLU())
    model.add(Dense(maze.size))
    model.add(PReLU())
    model.add(Dense(num_actions))
    model.compile(optimizer='adam', loss='mse')
    return model


@tf.function
def train_step(x, y):
    with tf.GradientTape() as tape:
        q_values = model(x, training=True)
        loss = loss_fn(y, q_values)
    grads = tape.gradient(loss, model.trainable_variables)
    optimizer.apply_gradients(zip(grads, model.trainable_variables))
    return loss


def qtrain(model, maze, **opt):
    # exploration factor
    global epsilon

    # Helper function to format elapsed time for display
    def format_time(seconds):
        if seconds < 400:
            s = float(seconds)
            return "%.1f seconds" % (s,)
        elif seconds < 4000:
            m = seconds / 60.0
            return "%.2f minutes" % (m,)
        else:
            h = seconds / 3600.0
            return "%.2f hours" % (h,)

    # Number of epochs
    n_epoch = opt.get('n_epoch', 15000)

    # Maximum memory to store episodes
    max_memory = opt.get('max_memory', 1000)

    # Maximum data size for training
    data_size = opt.get('data_size', 50)

    # Frequency of target network updates
    target_update_freq = opt.get('target_update_freq', 50)

    # Start time
    start_time = datetime.datetime.now()

    # Construct environment/game from numpy array
    qmaze = TreasureMaze(maze)

    # Target Network to better guide training
    target_model = clone_model(model)
    target_model.set_weights(model.get_weights())

    # Initialize experience replay object
    experience = GameExperience(model, target_model, max_memory=max_memory)

    win_history = []
    hsize = qmaze.maze.size // 2
    win_rate = 0.0
    n_episodes = 0
    loss = 0.0

    # =============START_HERE=================
    for epoch in range(n_epoch):
        # Win rate over last hsize steps
        win_rate = sum(win_history[-hsize:]) / hsize if len(win_history) >= hsize else 0.0

        # Print the epoch, loss, episode, win count, win rate, and time for each epoch
        dt = datetime.datetime.now() - start_time
        t = format_time(dt.total_seconds())
        print("Epoch: {:03d}/{:d} | Loss: {:.4f} | Episodes: {:d} | Win count: {:d} | Win rate: {:.3f} | time: {}".format(
            epoch, n_epoch-1, loss, n_episodes, sum(win_history), win_rate, t))

        # Reset the environment at a random free cell for each epoch
        agent_cell = random.choice(qmaze.free_cells)
        qmaze.reset(agent_cell)

        # Set the initial environment state from the current maze observation
        env_state = qmaze.observe()

        # Reset loss for this epoch
        loss = 0.0

        # Run the game loop until the game is over (win or lose)
        while True:
            # Save the current state before taking action
            previous_envstate = env_state

            # Decide on an action using epsilon-greedy exploration strategy
            if np.random.rand() < epsilon:
                # Exploration: randomly choose from valid actions available
                valid = qmaze.valid_actions()
                if valid:
                    action = random.choice(valid)
                else:
                    action = random.randint(0, num_actions - 1)
            else:
                # Exploitation: use the model to predict the best action
                action = np.argmax(experience.predict(env_state))

            # Take the chosen action and retrieve new state, reward, and game status
            env_state, reward, game_status = qmaze.act(action)

            # Track wins and losses using win_history
            if game_status == 'win':
                win_history.append(1)
                n_episodes += 1
                break
            elif game_status == 'lose':
                win_history.append(0)
                n_episodes += 1
                break

            # Store the episode in the experience replay memory
            episode = [previous_envstate, action, reward, env_state, game_status]
            experience.remember(episode)

            # Train the neural network model and evaluate loss
            # Get training data from experience replay and run a training step
            inputs, targets = experience.get_data(batch_size=data_size)
            batch_loss = train_step(inputs, targets)
            loss += batch_loss

        # Update target network weights periodically to stabilize training
        if epoch % target_update_freq == 0:
            target_model.set_weights(model.get_weights())

        # Adjust epsilon based on win rate
        if win_rate > 0.9:
            epsilon = 0.05
        else:
            epsilon = max(epsilon * epsilon_decay, epsilon_min)

        # Check if win rate threshold is met and agent consistently wins
        if win_rate >= 0.999 and completion_check(model, maze):
            print(f"Reached 100% win rate at epoch {epoch}")
            break

    total_time = format_time((datetime.datetime.now() - start_time).total_seconds())
    print("Training complete in:", total_time)
