import numpy as np


class PrioritizedReplayBuffer:
    """
    Custom data structure for the CS 499 algorithms/data structures
    enhancement. Stores past game episodes together with a priority value
    and samples training batches with probability proportional to each
    episode's priority (derived from its TD-error), instead of sampling
    uniformly at random the way the original GameExperience class does.
    This means the agent spends more training time on the experiences it
    is currently predicting worst, rather than treating every past episode
    as equally useful to learn from.
    """

    def __init__(self, capacity, alpha=0.6):
        self.capacity = capacity
        self.alpha = alpha
        self.buffer = []
        self.priorities = np.zeros((capacity,), dtype=np.float32)
        self.pos = 0

    def __len__(self):
        return len(self.buffer)

    def store(self, episode, priority=None):
        max_priority = self.priorities[:len(self.buffer)].max() if self.buffer else 1.0
        p = max_priority if priority is None else priority

        if len(self.buffer) < self.capacity:
            self.buffer.append(episode)
        else:
            self.buffer[self.pos] = episode

        self.priorities[self.pos] = p
        self.pos = (self.pos + 1) % self.capacity

    def sample(self, batch_size):
        n = len(self.buffer)
        prios = self.priorities[:n] ** self.alpha
        probs = prios / prios.sum()
        batch_size = min(batch_size, n)
        indices = np.random.choice(n, batch_size, replace=False, p=probs)
        samples = [self.buffer[i] for i in indices]
        return samples, indices

    def update_priorities(self, indices, td_errors):
        for idx, err in zip(indices, td_errors):
            self.priorities[idx] = abs(err) + 1e-5
