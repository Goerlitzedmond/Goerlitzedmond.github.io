# Enhanced training loop: Prioritized Experience Replay
# Uses the same model, train_step, and loss_fn as the original qtrain()
# (unchanged); only the sampling source is new (see prioritized_replay_buffer.py)

from prioritized_replay_buffer import PrioritizedReplayBuffer

def qtrain_per(model, maze, **opt):
    global epsilon

    def format_time(seconds):
        if seconds < 400:
            return "%.1f seconds" % (float(seconds),)
        elif seconds < 4000:
            return "%.2f minutes" % (seconds / 60.0,)
        else:
            return "%.2f hours" % (seconds / 3600.0,)

    n_epoch = opt.get('n_epoch', 15000)
    max_memory = opt.get('max_memory', 1000)
    data_size = opt.get('data_size', 50)
    target_update_freq = opt.get('target_update_freq', 50)

    start_time = datetime.datetime.now()
    qmaze = TreasureMaze(maze)

    target_model = clone_model(model)
    target_model.set_weights(model.get_weights())

    per_buffer = PrioritizedReplayBuffer(capacity=max_memory)

    win_history = []
    hsize = qmaze.maze.size // 2
    win_rate = 0.0
    n_episodes = 0
    loss = 0.0
    epoch = 0

    for epoch in range(n_epoch):
        win_rate = sum(win_history[-hsize:]) / hsize if len(win_history) >= hsize else 0.0

        dt = datetime.datetime.now() - start_time
        t = format_time(dt.total_seconds())
        print("Epoch: {:03d}/{:d} | Loss: {:.4f} | Episodes: {:d} | Win count: {:d} | Win rate: {:.3f} | time: {}".format(
            epoch, n_epoch - 1, loss, n_episodes, sum(win_history), win_rate, t))

        agent_cell = random.choice(qmaze.free_cells)
        qmaze.reset(agent_cell)
        env_state = qmaze.observe()
        loss = 0.0

        while True:
            previous_envstate = env_state

            if np.random.rand() < epsilon:
                valid = qmaze.valid_actions()
                action = random.choice(valid) if valid else random.randint(0, num_actions - 1)
            else:
                state = np.asarray(env_state, dtype=np.float32)
                q_values = model(state, training=False).numpy()[0]
                action = np.argmax(q_values)

            env_state, reward, game_status = qmaze.act(action)

            if game_status == 'win':
                win_history.append(1)
                n_episodes += 1
                break
            elif game_status == 'lose':
                win_history.append(0)
                n_episodes += 1
                break

            episode = (previous_envstate, action, reward, env_state, game_status)
            per_buffer.store(episode)

            batch, indices = per_buffer.sample(data_size)
            env_size = previous_envstate.shape[1]
            inputs = np.zeros((len(batch), env_size), dtype=np.float32)
            targets = np.zeros((len(batch), num_actions), dtype=np.float32)
            td_errors = np.zeros((len(batch),), dtype=np.float32)

            for i, (b_state, b_action, b_reward, b_next_state, b_status) in enumerate(batch):
                state_arr = np.asarray(b_state, dtype=np.float32)
                next_state_arr = np.asarray(b_next_state, dtype=np.float32)

                inputs[i] = state_arr
                old_q = model(state_arr, training=False).numpy()[0]
                targets[i] = old_q

                if b_status == 'win' or b_status == 'lose':
                    new_q = b_reward
                else:
                    next_q = target_model(next_state_arr, training=False).numpy()[0]
                    new_q = b_reward + discount * np.max(next_q)

                td_errors[i] = abs(new_q - old_q[b_action])
                targets[i, b_action] = new_q

            batch_loss = train_step(inputs, targets)
            loss += batch_loss
            per_buffer.update_priorities(indices, td_errors)

        if epoch % target_update_freq == 0:
            target_model.set_weights(model.get_weights())

        if win_rate > 0.9:
            epsilon = 0.05
        else:
            epsilon = max(epsilon * epsilon_decay, epsilon_min)

        if win_rate >= 0.999 and completion_check(model, maze):
            print(f"Reached 100% win rate at epoch {epoch}")
            break

    total_time = format_time((datetime.datetime.now() - start_time).total_seconds())
    print("Training complete in:", total_time)
    return epoch
