const test = require('node:test');
const assert = require('node:assert/strict');
const Trip = require('../models/travlr');
const controller = require('../controllers/trips');

// A minimal stand-in for Express's response object that records what was sent.
const mockRes = () => {
    const res = { statusCode: null, body: undefined, ended: false };
    res.status = (code) => { res.statusCode = code; return res; };
    res.json = (body) => { res.body = body; return res; };
    res.send = (body) => { res.ended = true; res.body = body; return res; };
    return res;
};

// Temporarily replaces a model method, then always restores it.
const withStub = async (name, impl, run) => {
    const original = Trip[name];
    Trip[name] = impl;
    try { await run(); } finally { Trip[name] = original; }
};

// Real Mongoose validation error, so the tests use the real error shape.
const realValidationError = async () => {
    try {
        await new Trip({ code: 'GALR210315', name: 'x', length: 'x', start: new Date(), resort: 'x', perPerson: 'free', image: 'a.jpg', description: 'x' }).validate();
    } catch (err) {
        return err;
    }
};

// Silences the server-side log line the 500 handler writes on purpose.
const quietly = async (run) => {
    const original = console.error;
    console.error = () => {};
    try { await run(); } finally { console.error = original; }
};

test('DELETE removes an existing trip and returns 204', async () => {
    let filter;
    await withStub('findOneAndDelete', async (f) => { filter = f; return { code: 'ABC123' }; }, async () => {
        const res = mockRes();
        await controller.tripsDelete({ params: { tripCode: 'ABC123' } }, res);
        assert.equal(res.statusCode, 204);
        assert.equal(res.ended, true);
        assert.deepEqual(filter, { code: 'ABC123' });
    });
});

test('DELETE returns 404 when the trip does not exist', async () => {
    await withStub('findOneAndDelete', async () => null, async () => {
        const res = mockRes();
        await controller.tripsDelete({ params: { tripCode: 'NOPE' } }, res);
        assert.equal(res.statusCode, 404);
        assert.equal(res.body.message, 'Trip not found');
    });
});

test('a database failure returns a generic 500 and leaks no internal details', async () => {
    await quietly(() =>
        withStub('findOneAndDelete', async () => { throw new Error('mongodb://admin:hunter2@10.0.0.5 refused'); }, async () => {
            const res = mockRes();
            await controller.tripsDelete({ params: { tripCode: 'ABC123' } }, res);
            assert.equal(res.statusCode, 500);
            assert.deepEqual(res.body, { message: 'Internal server error' });
            assert.ok(!JSON.stringify(res.body).includes('hunter2'));
        })
    );
});

test('PUT runs schema validators and returns the updated trip', async () => {
    let args;
    await withStub('findOneAndUpdate', async (...a) => { args = a; return { code: 'ABC123', name: 'New' }; }, async () => {
        const res = mockRes();
        await controller.tripsUpdate({ params: { tripCode: 'ABC123' }, body: { name: 'New' } }, res);
        assert.equal(res.statusCode, 200);
        assert.equal(args[2].runValidators, true);
        assert.equal(args[2].new, true);
    });
});

test('PUT only sends the fields the client provided and ignores unknown fields', async () => {
    let update;
    await withStub('findOneAndUpdate', async (f, u) => { update = u; return {}; }, async () => {
        await controller.tripsUpdate(
            { params: { tripCode: 'ABC123' }, body: { name: 'New', isAdmin: true, $set: { code: 'X' } } },
            mockRes()
        );
        assert.deepEqual(update, { name: 'New' });
    });
});

test('PUT returns 400 with per-field messages when validation fails', async () => {
    const err = await realValidationError();
    await withStub('findOneAndUpdate', async () => { throw err; }, async () => {
        const res = mockRes();
        await controller.tripsUpdate({ params: { tripCode: 'ABC123' }, body: {} }, res);
        assert.equal(res.statusCode, 400);
        assert.equal(res.body.message, 'Validation failed');
        assert.ok(res.body.errors.perPerson);
    });
});

test('PUT returns 404 when the trip does not exist', async () => {
    await withStub('findOneAndUpdate', async () => null, async () => {
        const res = mockRes();
        await controller.tripsUpdate({ params: { tripCode: 'NOPE' }, body: { name: 'x' } }, res);
        assert.equal(res.statusCode, 404);
    });
});

test('POST returns 201 with the created trip', async () => {
    await withStub('create', async (data) => data, async () => {
        const res = mockRes();
        await controller.tripsAdd({ body: { code: 'ABC123', name: 'x', extra: 'ignored' } }, res);
        assert.equal(res.statusCode, 201);
        assert.deepEqual(res.body, { code: 'ABC123', name: 'x' });
    });
});

test('POST returns 400 when validation fails', async () => {
    const err = await realValidationError();
    await withStub('create', async () => { throw err; }, async () => {
        const res = mockRes();
        await controller.tripsAdd({ body: {} }, res);
        assert.equal(res.statusCode, 400);
        assert.ok(res.body.errors.perPerson);
    });
});

test('POST returns 409 when the trip code already exists', async () => {
    await withStub('create', async () => { const e = new Error('E11000 duplicate key'); e.code = 11000; throw e; }, async () => {
        const res = mockRes();
        await controller.tripsAdd({ body: {} }, res);
        assert.equal(res.statusCode, 409);
        assert.equal(res.body.message, 'A trip with that code already exists');
    });
});

test('GET one returns 404 for an unknown code and the array for a known one', async () => {
    await withStub('find', async () => [], async () => {
        const res = mockRes();
        await controller.tripsOne({ params: { tripCode: 'NOPE' } }, res);
        assert.equal(res.statusCode, 404);
    });
    await withStub('find', async () => [{ code: 'ABC123' }], async () => {
        const res = mockRes();
        await controller.tripsOne({ params: { tripCode: 'ABC123' } }, res);
        assert.equal(res.statusCode, 200);
        assert.deepEqual(res.body, [{ code: 'ABC123' }]);
    });
});

test('a cast error returns 400 instead of a server error', async () => {
    await withStub('find', async () => { const e = new Error('cast'); e.name = 'CastError'; e.path = 'start'; throw e; }, async () => {
        const res = mockRes();
        await controller.tripsOne({ params: { tripCode: 'x' } }, res);
        assert.equal(res.statusCode, 400);
        assert.equal(res.body.message, 'Invalid value for start');
    });
});
