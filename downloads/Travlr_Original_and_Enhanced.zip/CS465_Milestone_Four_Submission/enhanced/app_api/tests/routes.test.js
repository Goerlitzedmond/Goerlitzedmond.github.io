const test = require('node:test');
const assert = require('node:assert/strict');
const router = require('../routes/index');
const controller = require('../controllers/trips');

const findRoute = (method, routePath) =>
    router.stack.find((layer) => layer.route && layer.route.path === routePath && layer.route.methods[method]);

test('a DELETE /trips/:tripCode route exists and calls the delete controller', () => {
    const layer = findRoute('delete', '/trips/:tripCode');
    assert.ok(layer, 'DELETE route is missing');
    const handlers = layer.route.stack.map((s) => s.handle);
    assert.equal(handlers[handlers.length - 1], controller.tripsDelete);
});

test('DELETE is protected by JWT authentication, the same as POST and PUT', () => {
    for (const [method, routePath] of [['post', '/trips'], ['put', '/trips/:tripCode'], ['delete', '/trips/:tripCode']]) {
        const layer = findRoute(method, routePath);
        assert.ok(layer, `${method} ${routePath} is missing`);
        const handlers = layer.route.stack;
        assert.equal(handlers.length, 2, `${method} ${routePath} should have an auth step plus a controller`);
        assert.equal(handlers[0].handle.name, 'authenticate', `${method} ${routePath} is not behind passport.authenticate`);
    }
});

test('reading trips stays public', () => {
    for (const routePath of ['/trips', '/trips/:tripCode']) {
        const layer = findRoute('get', routePath);
        assert.ok(layer);
        assert.equal(layer.route.stack.length, 1);
    }
});
