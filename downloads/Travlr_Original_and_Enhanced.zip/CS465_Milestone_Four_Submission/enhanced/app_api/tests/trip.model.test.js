const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const Trip = require('../models/travlr');

const validTrip = () => ({
    code: 'GALR210315',
    name: 'Gale Reef',
    length: '4 nights / 5 days',
    start: new Date('2026-03-15'),
    resort: 'Emerald Bay, 3 stars',
    perPerson: '$799.00',
    image: 'images/gale-reef.jpg',
    description: '<p>A relaxing reef getaway.</p>'
});

// Runs the schema's validators and returns the error (or undefined if the data is valid).
const validate = async (data) => {
    try {
        await new Trip(data).validate();
        return undefined;
    } catch (err) {
        return err;
    }
};

test('a complete, well-formed trip passes validation', async () => {
    assert.equal(await validate(validTrip()), undefined);
});

for (const field of ['code', 'name', 'length', 'start', 'resort', 'perPerson', 'image', 'description']) {
    test(`a trip without ${field} is rejected`, async () => {
        const data = validTrip();
        delete data[field];
        const err = await validate(data);
        assert.ok(err, 'expected a validation error');
        assert.ok(err.errors[field], `expected an error on ${field}`);
    });
}

test('a field containing only whitespace counts as missing', async () => {
    const err = await validate({ ...validTrip(), name: '   ' });
    assert.ok(err && err.errors.name);
});

test('surrounding whitespace is trimmed before saving', async () => {
    const trip = new Trip({ ...validTrip(), code: '  ABC123  ', name: '  Gale Reef ' });
    assert.equal(trip.code, 'ABC123');
    assert.equal(trip.name, 'Gale Reef');
});

test('trip codes must be 3 to 30 characters of letters, numbers, dash or underscore', async () => {
    assert.ok((await validate({ ...validTrip(), code: 'AB' })).errors.code, 'too short');
    assert.ok((await validate({ ...validTrip(), code: 'A'.repeat(31) })).errors.code, 'too long');
    assert.ok((await validate({ ...validTrip(), code: 'GALR 2103' })).errors.code, 'contains a space');
    assert.ok((await validate({ ...validTrip(), code: '{"$gt":""}' })).errors.code, 'contains operator characters');
    assert.equal(await validate({ ...validTrip(), code: 'GALR-2103_a' }), undefined);
});

test('perPerson accepts normal prices and rejects everything else', async () => {
    for (const ok of ['799', '799.00', '$799.00', '$1,299.00', '1,299']) {
        assert.equal(await validate({ ...validTrip(), perPerson: ok }), undefined, `should accept ${ok}`);
    }
    for (const bad of ['free', '$-5', '12.345', '$', '799 dollars', '<b>9</b>']) {
        assert.ok((await validate({ ...validTrip(), perPerson: bad })).errors.perPerson, `should reject ${bad}`);
    }
});

test('image must be a path or URL with no spaces, quotes or angle brackets', async () => {
    assert.equal(await validate({ ...validTrip(), image: 'https://example.com/a/b.jpg' }), undefined);
    for (const bad of ['images/a b.jpg', 'x" onerror="alert(1)', '<script>alert(1)</script>']) {
        assert.ok((await validate({ ...validTrip(), image: bad })).errors.image, `should reject ${bad}`);
    }
});

test('overlong values are rejected', async () => {
    assert.ok((await validate({ ...validTrip(), name: 'x'.repeat(101) })).errors.name);
    assert.ok((await validate({ ...validTrip(), description: 'x'.repeat(4001) })).errors.description);
});

test('start must be a real date', async () => {
    assert.ok((await validate({ ...validTrip(), start: 'not a date' })).errors.start);
});

test('code has a unique index declared, so duplicate codes are impossible', async () => {
    assert.equal(Trip.schema.path('code').options.unique, true);
    const indexes = Trip.schema.indexes();
    assert.ok(indexes.some(([fields, options]) => fields.code === 1 && options.unique === true));
});

// Confirms the stricter rules do not reject the trips the app already has.
const seedPath = path.join(__dirname, '..', '..', 'data', 'trips.json');
test('every trip in data/trips.json passes the new schema', { skip: !fs.existsSync(seedPath) && 'data/trips.json not found' }, async () => {
    const trips = JSON.parse(fs.readFileSync(seedPath, 'utf8'));
    assert.ok(Array.isArray(trips) && trips.length > 0);
    for (const data of trips) {
        const err = await validate(data);
        assert.equal(err, undefined, `trip ${data.code} failed: ${err && Object.values(err.errors).map(e => e.message).join('; ')}`);
    }
    const codes = trips.map(t => t.code);
    assert.equal(new Set(codes).size, codes.length, 'seed data contains duplicate trip codes');
});
