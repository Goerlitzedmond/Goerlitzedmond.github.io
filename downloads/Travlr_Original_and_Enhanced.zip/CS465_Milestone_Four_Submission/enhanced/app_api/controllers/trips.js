const Trip = require('../models/travlr');

// Only these fields are ever read from a request body. Anything else a client
// sends is ignored, and fields that were not sent are not overwritten.
const TRIP_FIELDS = ['code', 'name', 'length', 'start', 'resort', 'perPerson', 'image', 'description'];

const pickTripFields = (body = {}) => {
    const data = {};
    for (const field of TRIP_FIELDS) {
        if (body[field] !== undefined) data[field] = body[field];
    }
    return data;
};

// Turns a database error into a safe response. Validation problems and duplicate
// codes are the client's to fix, so they get a clear message. Anything else is
// logged on the server and the client only sees a generic message, so internal
// details (connection strings, stack traces, schema internals) never leak.
const sendError = (res, err) => {
    if (err && err.name === 'ValidationError') {
        const errors = {};
        for (const [field, problem] of Object.entries(err.errors)) {
            errors[field] = problem.message;
        }
        return res.status(400).json({ message: 'Validation failed', errors });
    }
    if (err && err.name === 'CastError') {
        return res.status(400).json({ message: `Invalid value for ${err.path}` });
    }
    if (err && err.code === 11000) {
        return res.status(409).json({ message: 'A trip with that code already exists' });
    }
    console.error(err);
    return res.status(500).json({ message: 'Internal server error' });
};

// GET: /api/trips - returns all trips
const tripsList = async (req, res) => {
    try {
        const trips = await Trip.find({});
        if (!trips) return res.status(404).json({ message: 'No trips found' });
        return res.status(200).json(trips);
    } catch (err) {
        return sendError(res, err);
    }
};

// GET: /api/trips/:tripCode - returns a single trip
// find() returns an array, so "not found" is an empty array rather than null.
// The array response shape is kept so existing clients keep working.
const tripsOne = async (req, res) => {
    try {
        const trip = await Trip.find({ code: req.params.tripCode });
        if (!trip || trip.length === 0) return res.status(404).json({ message: 'Trip not found' });
        return res.status(200).json(trip);
    } catch (err) {
        return sendError(res, err);
    }
};

// POST: /api/trips - adds a new trip (schema validation runs on create)
const tripsAdd = async (req, res) => {
    try {
        const trip = await Trip.create(pickTripFields(req.body));
        return res.status(201).json(trip);
    } catch (err) {
        return sendError(res, err);
    }
};

// PUT: /api/trips/:tripCode - updates a trip
// runValidators makes the schema rules apply to updates too. Without it,
// findOneAndUpdate skips validation and a bad edit could be saved.
const tripsUpdate = async (req, res) => {
    try {
        const trip = await Trip.findOneAndUpdate(
            { code: req.params.tripCode },
            pickTripFields(req.body),
            { new: true, runValidators: true }
        );
        if (!trip) return res.status(404).json({ message: 'Trip not found' });
        return res.status(200).json(trip);
    } catch (err) {
        return sendError(res, err);
    }
};

// DELETE: /api/trips/:tripCode - removes a trip (new in this enhancement)
const tripsDelete = async (req, res) => {
    try {
        const trip = await Trip.findOneAndDelete({ code: req.params.tripCode });
        if (!trip) return res.status(404).json({ message: 'Trip not found' });
        return res.status(204).send();
    } catch (err) {
        return sendError(res, err);
    }
};

module.exports = { tripsList, tripsOne, tripsAdd, tripsUpdate, tripsDelete };
