const mongoose = require('mongoose');

// Format rules. They are deliberately loose enough that the existing trip data
// still passes (the seed-data test in app_api/tests checks data/trips.json).
const CODE_FORMAT = /^[A-Za-z0-9_-]+$/;                 // letters, digits, dash, underscore
const PRICE_FORMAT = /^\$?\d+(,\d{3})*(\.\d{1,2})?$/;   // 799, $799.00, 1,299.00
const IMAGE_FORMAT = /^[A-Za-z0-9_\-./:%]+$/;           // a path or URL: no spaces, quotes, or angle brackets

// Define the trip schema.
// Enhancement: every field now has schema-level validation, so bad data is
// rejected by the data layer itself no matter which route or script writes it.
const tripSchema = new mongoose.Schema({
    // unique: true creates a unique index. A trip code identifies a trip in every
    // route (GET one, PUT, DELETE), so two trips must never share one.
    code: {
        type: String,
        required: [true, 'code is required'],
        unique: true,
        trim: true,
        minlength: [3, 'code must be at least 3 characters'],
        maxlength: [30, 'code must be 30 characters or fewer'],
        match: [CODE_FORMAT, 'code may only contain letters, numbers, dashes, and underscores']
    },
    name: {
        type: String,
        required: [true, 'name is required'],
        index: true,
        trim: true,
        maxlength: [100, 'name must be 100 characters or fewer']
    },
    length: {
        type: String,
        required: [true, 'length is required'],
        trim: true,
        maxlength: [50, 'length must be 50 characters or fewer']
    },
    start: {
        type: Date,
        required: [true, 'start is required']
    },
    resort: {
        type: String,
        required: [true, 'resort is required'],
        trim: true,
        maxlength: [100, 'resort must be 100 characters or fewer']
    },
    perPerson: {
        type: String,
        required: [true, 'perPerson is required'],
        trim: true,
        match: [PRICE_FORMAT, 'perPerson must be a price such as 799.00 or $1,299.00']
    },
    image: {
        type: String,
        required: [true, 'image is required'],
        trim: true,
        maxlength: [300, 'image must be 300 characters or fewer'],
        match: [IMAGE_FORMAT, 'image must be a file path or URL without spaces or special characters']
    },
    description: {
        type: String,
        required: [true, 'description is required'],
        trim: true,
        maxlength: [4000, 'description must be 4000 characters or fewer']
    }
});

const Trip = mongoose.model('trips', tripSchema);
module.exports = Trip;
