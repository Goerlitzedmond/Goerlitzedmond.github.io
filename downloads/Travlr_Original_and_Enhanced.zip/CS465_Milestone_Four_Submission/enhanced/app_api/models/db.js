const mongoose = require('mongoose');
const host = process.env.DB_HOST || '127.0.0.1';
const dbURI = `mongodb://${host}/travlr`;
const readLine = require('readline');

// Build the connection string and set the connection timeout
const connect = () => {
    setTimeout(() => mongoose.connect(dbURI, {}), 1000);
}

// Monitor connection events
mongoose.connection.on('connected', () => {
    console.log(`Mongoose connected to ${dbURI}`);
    // Enhancement: bring the database's indexes in line with the schema. An
    // existing database already has a plain (non-unique) index on code, and
    // MongoDB will not change its options in place, so the new unique index on
    // code would silently never be applied without this. If duplicate codes
    // already exist the unique index cannot be built; the error is logged and
    // the app keeps running so the duplicates can be cleaned up.
    mongoose.model('trips').syncIndexes()
        .then(() => console.log('Trip indexes synchronized'))
        .catch(err => console.log('Trip index sync error: ', err.message));
});
mongoose.connection.on('error', err => {
    console.log('Mongoose connection error: ', err);
});
mongoose.connection.on('disconnected', () => {
    console.log('Mongoose disconnected');
});

// Configure for Graceful Shutdown
const gracefulShutdown = (msg) => {
    mongoose.connection.close(() => {
        console.log(`Mongoose disconnected through ${msg}`);
    });
};

// Shutdown invoked by nodemon signal
process.once('SIGUSR2', () => {
    gracefulShutdown('nodemon restart');
    process.kill(process.pid, 'SIGUSR2');
});

// Shutdown invoked by app termination
process.on('SIGINT', () => {
    gracefulShutdown('app termination');
    process.exit(0);
});

// Shutdown invoked by container termination
process.on('SIGTERM', () => {
    gracefulShutdown('app shutdown');
    process.exit(0);
});

// Make initial connection to DB
connect();

// Import Mongoose schema
require('./travlr');
module.exports = mongoose;
