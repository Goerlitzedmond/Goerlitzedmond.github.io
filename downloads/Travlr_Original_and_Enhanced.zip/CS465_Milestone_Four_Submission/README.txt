CS 499 Milestone Four: Enhancement Three, Databases
Artifact: Travlr Getaways (CS 465), database layer

original/   The files exactly as they were before the enhancement.
enhanced/   The same files after the enhancement, plus a new app_api/tests/ folder.

Only the files touched by the enhancement are included. The rest of the
application (Angular admin app, Handlebars site, authentication code, seed
data) is unchanged.

What changed
  app_api/models/travlr.js           Schema validation on every field, unique trip code
  app_api/models/db.js               Index synchronization on connect
  app_api/controllers/trips.js       DELETE controller, validators on update, field
                                     restriction, safe error responses, 404 fix
  app_api/routes/index.js            DELETE /api/trips/:tripCode behind JWT authentication
  package.json                       "test" script (no new dependencies)
  app_api/tests/                     33 automated tests (Node's built-in test runner,
                                     no database required)

Running the tests
Copy the files in enhanced/ over the matching files in the project, then run:
  npm test
