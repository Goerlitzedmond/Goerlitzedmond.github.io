package com.goerlitzedmond.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {

    // UI elements for the add item form
    private EditText editTextItemName;
    private EditText editTextDescription;
    private EditText editTextQuantity;
    private Button buttonSaveItem;
    private Button buttonCancel;

    // Database helper instance
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        // Initialize the database helper
        databaseHelper = new DatabaseHelper(this);

        // Find UI elements by their IDs
        editTextItemName = findViewById(R.id.editTextItemName);
        editTextDescription = findViewById(R.id.editTextDescription);
        editTextQuantity = findViewById(R.id.editTextQuantity);
        buttonSaveItem = findViewById(R.id.buttonSaveItem);
        buttonCancel = findViewById(R.id.buttonCancel);

        // Save item to database when save button is clicked
        buttonSaveItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleSaveItem();
            }
        });

        // Return to inventory screen without saving when cancel is clicked
        buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    // Validate inputs and save the new item to the database
    private void handleSaveItem() {
        String name = editTextItemName.getText().toString().trim();
        String description = editTextDescription.getText().toString().trim();
        String quantityStr = editTextQuantity.getText().toString().trim();

        // Check that required fields are not empty
        if (name.isEmpty()) {
            Toast.makeText(this, "Please enter an item name", Toast.LENGTH_SHORT).show();
            return;
        }

        if (quantityStr.isEmpty()) {
            Toast.makeText(this, "Please enter a quantity", Toast.LENGTH_SHORT).show();
            return;
        }

        // Parse quantity as an integer
        int quantity;
        try {
            quantity = Integer.parseInt(quantityStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid quantity", Toast.LENGTH_SHORT).show();
            return;
        }

        // Insert the new item into the database
        if (databaseHelper.addItem(name, description, quantity)) {
            Toast.makeText(this, name + " added to inventory", Toast.LENGTH_SHORT).show();
            finish(); // Return to inventory screen
        } else {
            Toast.makeText(this, "Error saving item", Toast.LENGTH_SHORT).show();
        }
    }
}
