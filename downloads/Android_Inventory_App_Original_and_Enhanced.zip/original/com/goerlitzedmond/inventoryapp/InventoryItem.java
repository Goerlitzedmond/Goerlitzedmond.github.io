package com.goerlitzedmond.inventoryapp;

public class InventoryItem {

    // Fields for each inventory item
    private int id;
    private String name;
    private String description;
    private int quantity;

    // Constructor to create an InventoryItem object
    public InventoryItem(int id, String name, String description, int quantity) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.quantity = quantity;
    }

    // Getters for each field
    public int getId() { return id; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public int getQuantity() { return quantity; }

    // Setter for quantity since it gets updated
    public void setQuantity(int quantity) { this.quantity = quantity; }
}
