package com.goerlitzedmond.inventoryapp;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import android.content.Context;

import androidx.arch.core.executor.testing.InstantTaskExecutorRule;
import androidx.room.Room;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

@RunWith(AndroidJUnit4.class)
public class InventoryDaoTest {

    // Makes LiveData update synchronously during tests instead of on a background thread
    @Rule
    public InstantTaskExecutorRule instantExecutorRule = new InstantTaskExecutorRule();

    private AppDatabase db;
    private InventoryDao dao;

    @Before
    public void createDb() {
        Context context = ApplicationProvider.getApplicationContext();
        // In-memory database — wiped when the process ends, never touches the real app data
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase.class)
                .allowMainThreadQueries()
                .build();
        dao = db.inventoryDao();
    }

    @After
    public void closeDb() {
        db.close();
    }

    // Helper: blocks until the LiveData emits a value, since LiveData is normally async
    private List<InventoryItem> getValue(androidx.lifecycle.LiveData<List<InventoryItem>> liveData) throws InterruptedException {
        AtomicReference<List<InventoryItem>> data = new AtomicReference<>();
        CountDownLatch latch = new CountDownLatch(1);
        androidx.lifecycle.Observer<List<InventoryItem>> observer = value -> {
            data.set(value);
            latch.countDown();
        };
        liveData.observeForever(observer);
        latch.await(2, TimeUnit.SECONDS);
        liveData.removeObserver(observer);
        return data.get();
    }

    @Test
    public void insertItem_andReadBack_returnsCorrectItem() throws InterruptedException {
        InventoryItem item = new InventoryItem("Printer Paper", "Letter size, 500-sheet ream", 10);
        dao.insert(item);

        List<InventoryItem> items = getValue(dao.getAllItems());

        assertEquals(1, items.size());
        assertEquals("Printer Paper", items.get(0).getName());
        assertEquals(10, items.get(0).getQuantity());
    }

    @Test
    public void updateQuantity_changesStoredQuantity() throws InterruptedException {
        InventoryItem item = new InventoryItem("Stapler", "Standard desktop stapler", 5);
        dao.insert(item);

        List<InventoryItem> items = getValue(dao.getAllItems());
        int itemId = items.get(0).getId();

        dao.updateQuantity(itemId, 3);
        List<InventoryItem> updatedItems = getValue(dao.getAllItems());

        assertEquals(3, updatedItems.get(0).getQuantity());
    }

    @Test
    public void deleteById_removesItemFromDatabase() throws InterruptedException {
        InventoryItem item = new InventoryItem("Notepad", "Legal pad, 50 sheets", 20);
        dao.insert(item);

        List<InventoryItem> items = getValue(dao.getAllItems());
        int itemId = items.get(0).getId();

        dao.deleteById(itemId);
        List<InventoryItem> remainingItems = getValue(dao.getAllItems());

        assertTrue(remainingItems.isEmpty());
    }
}
