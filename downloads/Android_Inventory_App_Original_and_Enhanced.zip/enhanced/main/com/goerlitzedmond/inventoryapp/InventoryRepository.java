package com.goerlitzedmond.inventoryapp;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class InventoryRepository {

    private final InventoryDao inventoryDao;
    private final LiveData<List<InventoryItem>> allItems;

    // Runs database writes off the main thread
    private static final ExecutorService databaseWriteExecutor = Executors.newFixedThreadPool(2);

    public InventoryRepository(Application application) {
        AppDatabase db = AppDatabase.getInstance(application);
        inventoryDao = db.inventoryDao();
        allItems = inventoryDao.getAllItems();
    }

    public LiveData<List<InventoryItem>> getAllItems() {
        return allItems;
    }

    public void insert(InventoryItem item) {
        databaseWriteExecutor.execute(() -> inventoryDao.insert(item));
    }

    public void updateQuantity(int itemId, int newQuantity) {
        databaseWriteExecutor.execute(() -> inventoryDao.updateQuantity(itemId, newQuantity));
    }

    public void deleteById(int itemId) {
        databaseWriteExecutor.execute(() -> inventoryDao.deleteById(itemId));
    }
}
