package com.goerlitzedmond.inventoryapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    // Request code for SMS permission
    private static final int SMS_PERMISSION_CODE = 100;

    // UI elements
    private RecyclerView recyclerViewInventory;
    private Button buttonAddItem;

    // ViewModel replaces the direct DatabaseHelper instance
    private InventoryViewModel inventoryViewModel;
    private InventoryAdapter inventoryAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Get (or create) the shared ViewModel for this app
        inventoryViewModel = new ViewModelProvider(this).get(InventoryViewModel.class);

        // Find UI elements
        recyclerViewInventory = findViewById(R.id.recyclerViewInventory);
        buttonAddItem = findViewById(R.id.buttonAddItem);

        // Set up RecyclerView with a linear layout
        recyclerViewInventory.setLayoutManager(new LinearLayoutManager(this));
        inventoryAdapter = new InventoryAdapter(new ArrayList<>());
        recyclerViewInventory.setAdapter(inventoryAdapter);

        // Observe the LiveData list — the adapter refreshes automatically
        // whenever the underlying data changes, so no manual reload is needed
        inventoryViewModel.getAllItems().observe(this, items -> {
            inventoryAdapter.setItems(items);
        });

        // Request SMS permission when the inventory screen opens
        requestSmsPermission();

        // Navigate to add item screen when button is clicked
        buttonAddItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InventoryActivity.this, AddItemActivity.class);
                startActivity(intent);
            }
        });
    }

    // Request SMS permission from the user
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }
    }

    // Handle the result of the SMS permission request
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied. Notifications disabled.",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Send an SMS alert when an item quantity reaches zero
    private void sendSmsAlert(String itemName) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                // Send to a default number — in production this would be user-configured
                smsManager.sendTextMessage("5551234567", null,
                        "Alert: " + itemName + " is out of stock!", null, null);
                Toast.makeText(this, "SMS alert sent for " + itemName, Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // RecyclerView adapter — manages the list of inventory items
    private class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ItemViewHolder> {

        private List<InventoryItem> items;

        public InventoryAdapter(List<InventoryItem> items) {
            this.items = items;
        }

        // Called by the LiveData observer whenever the database changes
        public void setItems(List<InventoryItem> newItems) {
            this.items = newItems;
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            // Inflate the row layout for each item
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_inventory_row, parent, false);
            return new ItemViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
            InventoryItem item = items.get(position);

            // Bind item data to the row views
            holder.textViewItemName.setText(item.getName());
            holder.textViewQuantity.setText(String.valueOf(item.getQuantity()));

            // Increase quantity button
            holder.buttonIncrease.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int newQuantity = item.getQuantity() + 1;
                    inventoryViewModel.updateQuantity(item.getId(), newQuantity);
                }
            });

            // Decrease quantity button
            holder.buttonDecrease.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int currentQuantity = item.getQuantity();
                    if (currentQuantity > 0) {
                        int newQuantity = currentQuantity - 1;
                        inventoryViewModel.updateQuantity(item.getId(), newQuantity);

                        // Send SMS alert if quantity reaches zero
                        if (newQuantity == 0) {
                            sendSmsAlert(item.getName());
                        }
                    }
                }
            });

            // Delete button — remove item from database; the LiveData observer
            // refreshes the list automatically once the deletion completes
            holder.buttonDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    inventoryViewModel.deleteById(item.getId());
                    Toast.makeText(InventoryActivity.this,
                            item.getName() + " deleted", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        // ViewHolder holds references to the views in each row
        class ItemViewHolder extends RecyclerView.ViewHolder {
            TextView textViewItemName;
            TextView textViewQuantity;
            Button buttonIncrease;
            Button buttonDecrease;
            Button buttonDelete;

            public ItemViewHolder(@NonNull View itemView) {
                super(itemView);
                textViewItemName = itemView.findViewById(R.id.textViewItemName);
                textViewQuantity = itemView.findViewById(R.id.textViewQuantity);
                buttonIncrease = itemView.findViewById(R.id.buttonIncrease);
                buttonDecrease = itemView.findViewById(R.id.buttonDecrease);
                buttonDelete = itemView.findViewById(R.id.buttonDelete);
            }
        }
    }
}
