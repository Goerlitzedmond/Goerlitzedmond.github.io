package com.goerlitzedmond.inventoryapp;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class InventoryViewModel extends AndroidViewModel {

    private final InventoryRepository repository;
    private final LiveData<List<InventoryItem>> allItems;

    public InventoryViewModel(@NonNull Application application) {
        super(application);
        repository = new InventoryRepository(application);
        allItems = repository.getAllItems();
    }

    public LiveData<List<InventoryItem>> getAllItems() {
        return allItems;
    }

    public void insert(InventoryItem item) {
        repository.insert(item);
    }

    public void updateQuantity(int itemId, int newQuantity) {
        repository.updateQuantity(itemId, newQuantity);
    }

    public void deleteById(int itemId) {
        repository.deleteById(itemId);
    }
}
