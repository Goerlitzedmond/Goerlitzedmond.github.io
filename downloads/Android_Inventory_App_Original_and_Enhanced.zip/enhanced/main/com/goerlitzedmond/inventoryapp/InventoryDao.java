package com.goerlitzedmond.inventoryapp;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface InventoryDao {

    @Insert
    long insert(InventoryItem item);

    @Update
    void update(InventoryItem item);

    @Delete
    void delete(InventoryItem item);

    @Query("SELECT * FROM items")
    LiveData<List<InventoryItem>> getAllItems();

    @Query("UPDATE items SET quantity = :newQuantity WHERE id = :itemId")
    void updateQuantity(int itemId, int newQuantity);

    @Query("DELETE FROM items WHERE id = :itemId")
    void deleteById(int itemId);
}
